public class Main {
    public static void main(String[] args) {
        System.out.println("Hello,my name is Urmat!");
        System.out.println("I´m future Back-End developer.");
        System.out.printf("I like %s","Java");
    }
}